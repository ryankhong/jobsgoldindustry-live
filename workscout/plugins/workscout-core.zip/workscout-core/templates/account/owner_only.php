<div class="row">
<div class="col-md-12">
	<div class="notification success closeable margin-bottom-30">
		<p><?php esc_html_e('Sorry, you can\'t view this page, please register account to get access.','workscout_core' ); ?></p>
	</div>
</div>
</div>